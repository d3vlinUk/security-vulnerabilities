# Python Sudoku Game

A simple Sudoku game implementation using Python Flask for the backend and vanilla JavaScript for the frontend.

## Setup and Installation

1. Make sure you're in the correct folder
```
cd /workshop/python/qdoku/
```

2. Run the Python Unit Tests
```bash
python -m pytest
```


## Running the Application

1. Run the Python application:
   ```bash
   python app.py
   ```
2. The application will be available on https://[******].cloudfront.net/proxy/8090 where [******] is cloudfront distribution that you're currently on.


## Features

- Generate new Sudoku puzzles
- Input numbers using a clean web interface
- Validate moves in real-time
- Check complete solutions
- Highlight invalid cells
- Start new games at any time

## Development

- Uses Poetry for dependency management
- Flask for the backend API
- Simple vanilla JavaScript frontend
- Type hints throughout Python code
- Includes basic test setup with pytest