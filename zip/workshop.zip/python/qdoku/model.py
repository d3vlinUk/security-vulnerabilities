import random
from service import SudokuService

class SudokuModel:
    def __init__(self):
        self.solution = None
        self.puzzle = None
        self.original_puzzle = None
        self.seed = 42 
        
    def generatePuzzle(self, use_new_seed=False):
        if not use_new_seed:
            random.seed(self.seed)
        else:
            random.seed(None)

        self.solution = [[0 for _ in range(9)] for _ in range(9)]
        self.fill_box(self.solution, 0, 0)
        self.fill_box(self.solution, 3, 3)
        self.fill_box(self.solution, 6, 6)
        self.solve_sudoku(self.solution)
        self.puzzle = [row[:] for row in self.solution]
        self.remove_numbers(self.puzzle)
        self.original_puzzle = [row[:] for row in self.puzzle]
        return self.solution, self.puzzle

    def check_solution(self, user_solution):
        check_solution = [[0 if cell == '' else cell for cell in row] for row in user_solution]
        return check_solution == self.solution

    def fill_box(self, grid, row, col):
        nums = list(range(1, 10))
        random.shuffle(nums)
        for i in range(3):
            for j in range(3):
                grid[row + i][col + j] = nums.pop()

    def is_valid(self, grid, row, col, num):
        for x in range(9):
            if grid[row][x] == num:
                return False
        for x in range(9):
            if grid[x][col] == num:
                return False
        start_row = row - row % 3
        start_col = col - col % 3
        for i in range(3):
            for j in range(3):
                if grid[i + start_row][j + start_col] == num:
                    return False
        return True

    def solve_sudoku(self, grid):
        find = self.find_empty(grid)
        if not find:
            return True
        else:
            row, col = find
        for i in range(1, 10):
            if self.is_valid(grid, row, col, i):
                grid[row][col] = i
                if self.solve_sudoku(grid):
                    return True
                grid[row][col] = 0
        return False

    def find_empty(self, grid):
        for i in range(len(grid)):
            for j in range(len(grid[0])):
                if grid[i][j] == 0:
                    return (i, j)
        return None

    def remove_numbers(self, grid):
        num_to_remove = SudokuService.generate_random_number()
        for _ in range(num_to_remove):
            while True:
                row = random.randint(0, 8)
                col = random.randint(0, 8)
                if grid[row][col] != 0:
                    grid[row][col] = 0
                    break