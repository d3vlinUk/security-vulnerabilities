from flask import Flask
from controller import SudokuController

app = Flask(__name__)
app.secret_key = 'your-secret-key-here'

controller = SudokuController()

@app.route('/')
def index():
    return controller.index()

@app.route('/check', methods=['POST'])
def check():
    return controller.check()

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8090,debug=True)