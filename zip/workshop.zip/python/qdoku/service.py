import random

class SudokuService:
    @staticmethod
    def generate_display_puzzle(puzzle):
        return [['' if cell == 0 else cell for cell in row] for row in puzzle]

    @staticmethod
    def format_original_puzzle(original_puzzle):
        return [[int(cell) if str(cell).isdigit() else 0 for cell in row] for row in original_puzzle]

    @staticmethod
    def parse_user_solution(form_data):
        user_solution = []
        for i in range(9):
            row = []
            for j in range(9):
                value = form_data.get(f'cell_{i}_{j}', '')
                if value.strip().isdigit():
                    row.append(int(value))
                else:
                    row.append('')
            user_solution.append(row)
        return user_solution

    @staticmethod
    def generate_random_number():
        return random.randint(40, 50)