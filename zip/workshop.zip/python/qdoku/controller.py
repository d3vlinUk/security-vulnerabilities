from flask import render_template, request, session
from model import SudokuModel
from service import SudokuService

class SudokuController:
    def __init__(self):
        self.model = SudokuModel()
        self.service = SudokuService()

    def index(self):
        solution, puzzle = self.model.generatePuzzle()
        display_puzzle = self.service.generate_display_puzzle(puzzle)
        session['solution'] = solution
        session['original_puzzle'] = self.model.original_puzzle
        session['current_puzzle'] = display_puzzle
        return render_template('index.html', puzzle=display_puzzle, solution=solution, original_puzzle=self.model.original_puzzle)

    def check(self):
        user_solution = self.service.parse_user_solution(request.form)
        solution = session.get('solution')
        original_puzzle = self.service.format_original_puzzle(session.get('original_puzzle'))
        
        session['current_puzzle'] = user_solution
        
        is_correct = self.model.check_solution(user_solution)
        return render_template('index.html', 
                            puzzle=user_solution,
                            solution=solution,
                            original_puzzle=original_puzzle,
                            message="Correct!" if is_correct else "Not quite right, try again!")