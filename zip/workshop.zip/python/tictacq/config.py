from dataclasses import dataclass
import os

@dataclass
class Config:
    """Configuration class for TicTacQ application."""
    DEBUG: bool = True
    TESTING: bool = False
    SECRET_KEY: str = os.environ.get('SECRET_KEY', 'dev-key-change-in-production')
    PORT: int = 8090
    
    BOARD_SIZE: int = 3
    WINNING_LENGTH: int = 3
    
    STATIC_FOLDER: str = 'static'
    
    WORKSHOP_MODE: bool = os.environ.get('WORKSHOP_MODE', 'False').lower() == 'false'
    PROXY_PATH: str = '/proxy'
    
    def __init__(self):
        self.PORT = int(os.environ.get('PORT', 8090))
        self.BASE_PREFIX = f'{self.PROXY_PATH}/{self.PORT}'
        
        if not self.WORKSHOP_MODE:
            self.APPLICATION_ROOT = '/'
        else:
            self.APPLICATION_ROOT = self.BASE_PREFIX
