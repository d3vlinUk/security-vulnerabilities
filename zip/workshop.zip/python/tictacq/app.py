
from flask import Flask, render_template, request, jsonify, url_for, send_from_directory
from werkzeug.middleware.proxy_fix import ProxyFix
from config import Config
from game.tictacq_game import TicTacQGame

def create_app(config_class=Config):
    config = config_class()
    
    app = Flask(__name__,
                static_folder=config.STATIC_FOLDER)
    
    app.config.from_object(config)
    
    @app.context_processor
    def utility_processor():
        def static_proxy_path(filename):
            if 'localhost' in request.host or '127.0.0.1' in request.host:
                return url_for('static', filename=filename)
            return f"/proxy/8090/static/{filename}"
        return dict(static_proxy_path=static_proxy_path)

    app.wsgi_app = ProxyFix(
        app.wsgi_app, x_for=1, x_proto=1, x_host=1, x_port=1, x_prefix=1
    )
    
    game = TicTacQGame()

    @app.route('/')
    def index():
        return render_template('index.html', 
                             board=game.board, 
                             status=f"Current player: {game.current_player}")

    @app.route('/static/<path:filename>')
    def serve_static(filename):
        return send_from_directory(app.static_folder, filename)

    @app.route('/api/move', methods=['POST'])
    def make_move():
        data = request.get_json()
        row = data.get('row')
        col = data.get('col')
        valid = game.make_move(row, col, game.current_player)
        return jsonify(game.get_state())

    @app.route('/api/reset', methods=['POST'])
    def reset_game():
        game.reset()
        return jsonify(game.get_state())

    return app

if __name__ == '__main__':
    app = create_app()
    app.run(host='0.0.0.0', 
            port=app.config['PORT'],
            debug=app.config['DEBUG'])
