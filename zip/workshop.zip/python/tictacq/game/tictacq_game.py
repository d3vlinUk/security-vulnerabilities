
class TicTacQGame:
    def __init__(self):
        self.board = [['' for _ in range(3)] for _ in range(3)]
        self.current_player = 'X'
        self.game_status = 'IN_PROGRESS'

    def make_move(self, row, col, player):

        if self.game_status != 'IN_PROGRESS':
            return False

        if self.is_valid_move(row, col):
            self.board[row][col] = player
            

            winner = self.check_winner()
            if winner:
                self.game_status = f'{winner}_WINS'
                return True

            if all(all(cell != '' for cell in row) for row in self.board):
                self.game_status = 'DRAW'
                return True
            
            self.current_player = 'O' if player == 'X' else 'X'
            return True
        return False

    def is_valid_move(self, row, col):
        return 0 <= row < 3 and 0 <= col < 3 and self.board[row][col] == ''

    def check_winner(self):

        for row in self.board:
            if row.count(row[0]) == 3 and row[0] != '':
                return row[0]

        for col in range(3):
            if self.board[0][col] == self.board[1][col] == self.board[2][col] != '':
                return self.board[0][col]

        if self.board[0][0] == self.board[1][1] == self.board[2][2] != '':
            return self.board[0][0]
        if self.board[0][2] == self.board[1][1] == self.board[2][0] != '':
            return self.board[0][2]

        return None

    def reset(self):
        self.board = [['' for _ in range(3)] for _ in range(3)]
        self.current_player = 'X'
        self.game_status = 'IN_PROGRESS'

    def get_state(self):
        return {
            'board': self.board,
            'currentPlayer': self.current_player,
            'status': self.game_status,
            'gameOver': self.game_status != 'IN_PROGRESS'
        }
