from qdoku.model import SudokuModel
from qdoku.service import SudokuService
from unittest.mock import patch
import pytest
import random

