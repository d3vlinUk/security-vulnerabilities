#!sh
mvn spring-boot:run  -Dspring-boot.run.profiles=local -Djava.library.path=/usr/local/opt/tomcat-native/lib
  