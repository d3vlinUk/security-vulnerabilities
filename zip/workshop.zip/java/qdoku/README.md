# Java Sudoku Game

A simple Sudoku game implementation using Java Corretta for the backend and vanilla JavaScript for the frontend.

## Setup and Installation

1. Ensure  you're running java-1.8.0-amazon-corretto. You can do this by setting JAVA_HOME to the correct version as shown below
```
export JAVA_HOME=/usr/lib/jvm/java-1.8.0-amazon-corretto

```

2. Run the following maven command to ensure everything is running
```
mvn clean verify
```

## Running the Application

1. Activate the poetry shell:
   ```bash
   mvn spring-boot:run
   ```
2. The application will be available on https://[******].cloudfront.net/proxy/8090 where [******] is cloudfront distribution that you're currently on.

## Features

- Generate new Sudoku puzzles
- Input numbers using a clean web interface
- Validate moves in real-time
- Check complete solutions
- Highlight invalid cells
- Start new games at any time

## Development

- Uses Poetry for dependency management
- Flask for the backend API
- Simple vanilla JavaScript frontend
- Type hints throughout Python code
- Includes basic test setup with pytest