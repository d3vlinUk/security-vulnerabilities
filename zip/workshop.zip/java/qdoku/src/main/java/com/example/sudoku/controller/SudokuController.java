package com.example.sudoku.controller;

import com.example.sudoku.service.SudokuService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import java.util.Map;


@Controller
public class SudokuController {
    private final SudokuService sudokuService;
    
    public SudokuController(SudokuService sudokuService) {
        this.sudokuService = sudokuService;
    }
    
    @GetMapping("/")
    public String index(Model model) {
        return "index";
    }
    
    @GetMapping("/api/board")
    @ResponseBody
    public int[][] getBoard() {
        return sudokuService.getBoard();
    }
    
    @PostMapping("/api/move")
    @ResponseBody
    public boolean makeMove(@RequestParam int row, @RequestParam int col, @RequestParam int value) {
        return sudokuService.makeMove(row, col, value);
    }
    
    @GetMapping("/api/check")
    @ResponseBody
    public Map<String, Object> checkSolution() {
        return sudokuService.checkSolution();
    }
    
    @PostMapping("/api/new-game")
    @ResponseBody
    public int[][] newGame() {
        return sudokuService.newGame();
    }
}
