package com.example.sudoku.service;

import com.example.sudoku.model.SudokuBoard;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Map;
import java.util.HashMap;

@Service
public class SudokuService {
    private SudokuBoard board;

    public SudokuService() {
        this.board = new SudokuBoard();
        this.board.generatePuzzle();
    }

    public int[][] getBoard() {
        return board.getBoard();
    }

    public boolean makeMove(int row, int col, int value) {
        if (board.isValidMove(row, col, value)) {
            board.setCell(row, col, value);
            return true;
        }
        return false;
    }

    public Map<String, Object> checkSolution() {
        List<int[]> invalidCells = board.getInvalidCells();
        Map<String, Object> response = new HashMap<>();
        response.put("valid", invalidCells.isEmpty());
        response.put("invalidCells", invalidCells);
        return response;
    }

    public int[][] newGame() {
        board = new SudokuBoard();
        board.generatePuzzle();
        return board.getBoard();
    }
}