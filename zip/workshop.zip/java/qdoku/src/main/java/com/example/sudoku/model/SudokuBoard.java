package com.example.sudoku.model;

import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.HashSet;
public class SudokuBoard {
    private int[][] board;
    private int[][] solution;
    
    public SudokuBoard() {
        this.board = new int[9][9];
        this.solution = new int[9][9];
    }
    
    public int[][] getBoard() {
        return board;
    }
    
    public void setCell(int row, int col, int value) {
        if (isValidMove(row, col, value)) {
            board[row][col] = value;
        }
    }
    
    public boolean isValidMove(int row, int col, int value) {
        for (int i = 0; i < 9; i++) {
            if (board[row][i] == value) return false;
        }
        
        for (int i = 0; i < 9; i++) {
            if (board[i][col] == value) return false;
        }

        int boxRow = row - row % 3;
        int boxCol = col - col % 3;
        for (int i = boxRow; i < boxRow + 3; i++) {
            for (int j = boxCol; j < boxCol + 3; j++) {
                if (board[i][j] == value) return false;
            }
        }
        
        return true;
    }
    
    public List<int[]> getInvalidCells() {
        List<int[]> invalidCells = new ArrayList<>();
        
        for (int i = 0; i < 9; i++) {
            for (int j = 0; j < 9; j++) {
                if (board[i][j] == 0) {
                    invalidCells.add(new int[]{i, j});
                }
            }
        }

        for (int i = 0; i < 9; i++) {
            Set<Integer> seen = new HashSet<>();
            for (int j = 0; j < 9; j++) {
                if (board[i][j] != 0 && !seen.add(board[i][j])) {
                    invalidCells.add(new int[]{i, j});
                }
            }
        }
        
        for (int j = 0; j < 9; j++) {
            Set<Integer> seen = new HashSet<>();
            for (int i = 0; i < 9; i++) {
                if (board[i][j] != 0 && !seen.add(board[i][j])) {
                    invalidCells.add(new int[]{i, j});
                }
            }
        }

        for (int boxRow = 0; boxRow < 9; boxRow += 3) {
            for (int boxCol = 0; boxCol < 9; boxCol += 3) {
                Set<Integer> seen = new HashSet<>();
                for (int i = 0; i < 3; i++) {
                    for (int j = 0; j < 3; j++) {
                        int value = board[boxRow + i][boxCol + j];
                        if (value != 0 && !seen.add(value)) {
                            invalidCells.add(new int[]{boxRow + i, boxCol + j});
                        }
                    }
                }
            }
        }
        
        return invalidCells;
    }
    
    private boolean isValidRow(int row) {
        boolean[] used = new boolean[10];
        for (int i = 0; i < 9; i++) {
            int value = board[row][i];
            if (value != 0) {
                if (used[value]) return false;
                used[value] = true;
            }
        }
        return true;
    }
    
    private boolean isValidColumn(int col) {
        boolean[] used = new boolean[10];
        for (int i = 0; i < 9; i++) {
            int value = board[i][col];
            if (value != 0) {
                if (used[value]) return false;
                used[value] = true;
            }
        }
        return true;
    }
    
    private boolean isValidBox(int startRow, int startCol) {
        boolean[] used = new boolean[10];
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                int value = board[startRow + i][startCol + j];
                if (value != 0) {
                    if (used[value]) return false;
                    used[value] = true;
                }
            }
        }
        return true;
    }
    
    public void generatePuzzle() {

        int[][] fixedSolution = {
            {5,3,4,6,7,8,9,1,2},
            {6,7,2,1,9,5,3,4,8},
            {1,9,8,3,4,2,5,6,7},
            {8,5,9,7,6,1,4,2,3},
            {4,2,6,8,5,3,7,9,1},
            {7,1,3,9,2,4,8,5,6},
            {9,6,1,5,3,7,2,8,4},
            {2,8,7,4,1,9,6,3,5},
            {3,4,5,2,8,6,1,7,9}
        };
        

        for (int i = 0; i < 9; i++) {
            System.arraycopy(fixedSolution[i], 0, board[i], 0, 9);
            System.arraycopy(fixedSolution[i], 0, solution[i], 0, 9);
        }

        int[][] removePattern = {
            {1,0,0,0,1,1,0,0,1},
            {0,1,0,1,0,0,0,1,0},
            {1,1,0,0,0,1,0,0,1},
            {0,0,1,1,0,0,1,0,0},
            {1,0,0,0,1,0,0,0,1},
            {0,0,1,0,0,1,1,0,0},
            {1,0,0,1,0,0,0,1,1},
            {0,1,0,0,0,1,0,1,0},
            {1,0,1,1,0,0,1,0,0}
        };
        

        for (int i = 0; i < 9; i++) {
            for (int j = 0; j < 9; j++) {
                if (removePattern[i][j] == 0) {
                    board[i][j] = 0;
                }
            }
        }
    }
    
    
    private boolean generateSolution(int row, int col) {
        if (col >= 9) {
            col = 0;
            row++;
        }
        
        if (row >= 9) return true;
        
        int[] numbers = {1,2,3,4,5,6,7,8,9};
        shuffleArray(numbers);
        
        for (int num : numbers) {
            if (isValidMove(row, col, num)) {
                board[row][col] = num;
                if (generateSolution(row, col + 1)) return true;
                board[row][col] = 0;
            }
        }
        
        return false;
    }
    
    private void shuffleArray(int[] array) {
        for (int i = array.length - 1; i > 0; i--) {
            int index = (int) (Math.random() * (i + 1));
            int temp = array[index];
            array[index] = array[i];
            array[i] = temp;
        }
    }
    
    private void removeNumbers() {
        int cellsToRemove = 50;
        while (cellsToRemove > 0) {
            int row = (int) (Math.random() * 9);
            int col = (int) (Math.random() * 9);
            if (board[row][col] != 0) {
                board[row][col] = 0;
                cellsToRemove--;
            }
        }
    }
}