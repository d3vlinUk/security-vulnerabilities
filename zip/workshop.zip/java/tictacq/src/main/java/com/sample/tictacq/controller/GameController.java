package com.sample.tictacq.controller;

import com.sample.tictacq.model.Game;
import com.sample.tictacq.model.GameStatus;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import java.util.HashMap;
import java.util.Map;
import javax.servlet.http.HttpSession;

@Controller
@SessionAttributes("game")
public class GameController {

    @ModelAttribute("game")
    public Game game() {
        return new Game();
    }

    @GetMapping("/")
    public String index(Model model) {
        if (!model.containsAttribute("game")) {
            model.addAttribute("game", new Game());
        }
        return "index";
    }

    @PostMapping("/move")
    @ResponseBody
    public Map<String, Object> makeMove(@RequestBody Map<String, Integer> move,
            @ModelAttribute("game") Game game,
            HttpSession session) {
        if (session.getAttribute("game") == null) {
            session.setAttribute("game", game);
        }

        int row = move.get("row");
        int col = move.get("col");

        boolean valid = game.makeMove(row, col);

        Map<String, Object> response = new HashMap<>();
        response.put("valid", valid);
        response.put("board", game.getBoard().getBoard());
        response.put("currentPlayer", game.getCurrentPlayer());
        response.put("status", game.getGameStatus());
        response.put("gameOver", game.getGameStatus() != GameStatus.IN_PROGRESS);

        return response;
    }

    @PostMapping("/reset")
    @ResponseBody
    public Map<String, Object> reset(@ModelAttribute("game") Game game) {
        game.reset();

        Map<String, Object> response = new HashMap<>();
        response.put("board", game.getBoard().getBoard());
        response.put("currentPlayer", game.getCurrentPlayer());
        response.put("status", game.getGameStatus());
        response.put("gameOver", false);

        return response;
    }

    @ModelAttribute
    public void handleMissingGame(HttpSession session) {
        if (session.getAttribute("game") == null) {
            session.setAttribute("game", new Game());
        }
    }
}
