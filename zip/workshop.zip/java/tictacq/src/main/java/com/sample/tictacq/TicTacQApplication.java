package com.sample.tictacq;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TicTacQApplication {
    public static void main(String[] args) {
        SpringApplication.run(TicTacQApplication.class, args);
    }
}