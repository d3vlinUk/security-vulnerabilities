package com.sample.tictacq;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class AppConfig {

    private static final Logger logger = LoggerFactory.getLogger(AppConfig.class);

    @Value("${app.base-path}")
    private String configuredBasePath;

    @Bean
    public String basePath() {
        String workshopMode = System.getenv("WORKSHOP_MODE");
        String result;

        if (workshopMode != null && workshopMode.equalsIgnoreCase("false")) {
            result = "";
        } else {
            result = configuredBasePath;
        }

        logger.info("Workshop Mode: {}, Base Path: {}", workshopMode, result);
        return result;
    }

    @Bean
    public WebMvcConfigurer webMvcConfigurer(String basePath) {
        return new WebMvcConfigurer() {
            @Override
            public void addResourceHandlers(ResourceHandlerRegistry registry) {
                logger.info("Configuring resource handlers with base path: {}", basePath);
                registry.addResourceHandler(basePath + "/**")
                        .addResourceLocations("classpath:/static/");
            }
        };
    }
}
