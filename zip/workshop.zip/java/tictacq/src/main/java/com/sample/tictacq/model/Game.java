package com.sample.tictacq.model;

import lombok.Getter;

@Getter
public class Game {
    private GameBoard board;
    private char currentPlayer;
    private GameStatus gameStatus;

    public Game() {
        this.board = new GameBoard();
        this.currentPlayer = 'X';
        this.gameStatus = GameStatus.IN_PROGRESS;
    }

    public boolean makeMove(int row, int col) {
        if (gameStatus != GameStatus.IN_PROGRESS) {
            return false;
        }

        if (!isValidMove(row, col)) {
            return false;
        }

        board.makeMove(row, col, currentPlayer);

        char winner = board.checkWinner();
        if (winner == 'X') {
            gameStatus = GameStatus.X_WINS;
            return true;
        } else if (winner == 'O') {
            gameStatus = GameStatus.O_WINS;
            return true;
        }

        boolean isDraw = true;
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                if (board.getBoard()[i][j] == ' ') {
                    isDraw = false;
                    break;
                }
            }
            if (!isDraw)
                break;
        }

        if (isDraw) {
            gameStatus = GameStatus.DRAW;
            return true;
        }

        currentPlayer = (currentPlayer == 'X') ? 'O' : 'X';
        return true;
    }

    private boolean isValidMove(int row, int col) {
        return row >= 0 && row < 3 && col >= 0 && col < 3 &&
                board.getBoard()[row][col] == ' ';
    }

    public void reset() {
        board = new GameBoard();
        currentPlayer = 'X';
        gameStatus = GameStatus.IN_PROGRESS;
    }

    public GameStatus getGameStatus() {
        return gameStatus;
    }

    public GameBoard getBoard() {
        return board;
    }

    public char getCurrentPlayer() {
        return currentPlayer;
    }
}
