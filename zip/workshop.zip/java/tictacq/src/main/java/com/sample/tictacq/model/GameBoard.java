package com.sample.tictacq.model;

public class GameBoard {
    private char[][] board;
    private static final int BOARD_SIZE = 3;
    
    public GameBoard() {
        board = new char[BOARD_SIZE][BOARD_SIZE];
        reset();
    }
    
    public void reset() {
        for (int i = 0; i < BOARD_SIZE; i++) {
            for (int j = 0; j < BOARD_SIZE; j++) {
                board[i][j] = ' ';
            }
        }
    }
    
    public boolean makeMove(int row, int col, char player) {
        if (isValidMove(row, col)) {
            board[row][col] = player;
            return true;
        }
        return false;
    }
    
    public boolean isValidMove(int row, int col) {
        return row >= 0 && row < BOARD_SIZE && 
               col >= 0 && col < BOARD_SIZE && 
               board[row][col] == ' ';
    }
    
    public char checkWinner() {
        for (int row = 0; row < BOARD_SIZE; row++) {
            if (board[row][0] != ' ' && 
                board[row][0] == board[row][1] && 
                board[row][1] == board[row][2]) {
                return board[row][0];
            }
        }
        
        for (int col = 0; col < BOARD_SIZE; col++) {
            if (board[0][col] != ' ' && 
                board[0][col] == board[1][col] && 
                board[1][col] == board[2][col]) {
                return board[0][col];
            }
        }
        
        if (board[0][0] != ' ' && 
            board[0][0] == board[1][1] && 
            board[1][1] == board[2][2]) {
            return board[0][0];
        }
        
        if (board[0][2] != ' ' && 
            board[0][2] == board[1][1] && 
            board[1][1] == board[2][0]) {
            return board[0][2];
        }

        boolean isDraw = true;
        for (int i = 0; i < BOARD_SIZE; i++) {
            for (int j = 0; j < BOARD_SIZE; j++) {
                if (board[i][j] == ' ') {
                    isDraw = false;
                    break;
                }
            }
            if (!isDraw) break;
        }
        
        return isDraw ? 'D' : ' ';
    }
    
    public char[][] getBoard() {
        return board;
    }
}